package examenDocumentacion;

/**
 * Clase CCuenta.java En ella aparece los campos y la funcionalidad que se va
 * utilizar en la clase TestCCuenta.java
 * 
 * @author Jose Manuel Garcia Valverde
 * 
 */
public class CCuenta {
	/**
	 * Campo nombre. Almacena el nombre del titular de la cuenta
	 */
	private String nombre;
	/**
	 * Campo cuenta. Almacena el numero de cuenta.
	 */
	private String cuenta;
	/**
	 * Campo saldo. Almacen el saldo que hay en la cuenta.
	 */
	private double saldo;
	/**
	 * Campo tipoInteres. Almacena el interes que genera el saldo disponible en
	 * la cuenta.
	 */
	private double tipoInteres;

	/**
	 * Constructor de CCuenta. Requiere de introducirle los datos String nombre
	 * y cuenta y los datos Double saldo y tipo.
	 * 
	 * @param nom
	 *            . Nombre.
	 * @param cue
	 *            . Cuenta.
	 * @param sal
	 *            . Saldo.
	 * @param tipo
	 *            . TipoInteres.
	 */
	public CCuenta(String nom, String cue, double sal, double tipo) {
		setNombre(nom);
		setCuenta(cue);
		setSaldo(sal);
		setTipoInteres(tipo);
	}

	/**
	 * Metodo que muestra el estado de la cuenta.
	 * 
	 * @return Saldo de la cuenta.
	 */
	public double estado() {
		return getSaldo();
	}

	/**
	 * Metodo para ingresar saldo en la cuenta.
	 * 
	 * @param cantidad
	 *            . Cantidad a ingresar.
	 * @throws Exception
	 */
	public void ingresar(double cantidad) throws Exception {
		if (cantidad < 0) {
			throw new Exception("No se puede ingresar una cantidad negativa");
		}
		setSaldo(getSaldo() + cantidad);
	}

	/**
	 * Metodo para retirar saldo de la cuenta.
	 * 
	 * @param cantidad
	 *            . Cantidad a retirar.
	 * @throws Exception
	 */
	public void retirar(double cantidad) throws Exception {
		if (cantidad < 0) {
			throw new Exception("No se puede retirar una cantidad negativa");
		}
		if (estado() < cantidad) {
			throw new Exception("No se hay suficiente saldo");
		}
		setSaldo(getSaldo() - cantidad);
	}

	/**
	 * Modifica el campo saldo
	 * 
	 * @param saldo
	 */
	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}

	/**
	 * Devuelve valor de el campo nombre.
	 * 
	 * @return Nombre
	 */
	String getNombre() {
		return nombre;
	}

	/**
	 * Modifica el campo nombre
	 * 
	 * @param nombre
	 */
	void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * Devuelve valor de el campo Cuenta
	 * 
	 * @return Cuenta
	 */
	String getCuenta() {
		return cuenta;
	}

	/**
	 * Modifica el campo cuenta.
	 * 
	 * @param cuenta
	 */
	void setCuenta(String cuenta) {
		this.cuenta = cuenta;
	}

	/**
	 * Devuelve valor de el campo Saldo.
	 * 
	 * @return Saldo
	 */
	double getSaldo() {
		return saldo;
	}

	/**
	 * Devuelve valor de el campo TipoInteres.
	 * 
	 * @return tipoInteres
	 */
	double getTipoInteres() {
		return tipoInteres;
	}

	/**
	 * Modifica el campo TipoInteres.
	 * 
	 * @param tipoInteres
	 */
	void setTipoInteres(double tipoInteres) {
		this.tipoInteres = tipoInteres;
	}
}
