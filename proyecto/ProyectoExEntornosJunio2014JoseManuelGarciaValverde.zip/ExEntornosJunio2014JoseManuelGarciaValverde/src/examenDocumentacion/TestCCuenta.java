package examenDocumentacion;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Clase TestCCuenta.java Se utiliza para probar la funcionalidad que hemos
 * creado en la clase CCuenta.java
 * 
 * @author d13gavaj
 * 
 */
public class TestCCuenta {
	/**
	 * Campo dato. Almacena un dato de tipo String
	 */
	private static BufferedReader dato;

	public static void main(String[] args) {
		dato = new BufferedReader(new InputStreamReader(System.in));
		CCuenta d13gavaj;

		int opcion = 0;
		d13gavaj = new CCuenta("Rigoberta Piedra", "0000-6523-85-678912345",
				2500, 0);
		do {
			try {
				mostrarMenu();
				opcion = recogerOpcion(dato);

				switch (opcion) {
				case 1:
					ingresar(dato, d13gavaj);
					break;
				case 2:
					retirar(dato, d13gavaj);
					break;
				case 3:
					System.out.println("Aaaaaaaaaadios");
				}
			} catch (IOException ex) {
				Logger.getLogger(TestCCuenta.class.getName()).log(Level.SEVERE,
						null, ex);
			}
		} while (opcion != 3);
		System.out.println("Saldo actual: " + d13gavaj.estado());
	}

	/**
	 * Metodo para utilizar la opcion retirar
	 * 
	 * @param dato
	 * @param cuenta1
	 * @throws IOException
	 */
	private static void retirar(BufferedReader dato, CCuenta cuenta1)
			throws IOException {
		System.out.println("Indica cantidad a retirar: ");
		float retirar = Integer.parseInt(dato.readLine());
		try {
			cuenta1.retirar(retirar);
		} catch (Exception e) {
			System.out.print("Fallo al retirar");
		}
	}

	/**
	 * Metodo para utilizar la opcion ingresar.
	 * 
	 * @param dato
	 * @param cuenta1
	 * @throws IOException
	 */
	private static void ingresar(BufferedReader dato, CCuenta cuenta1)
			throws IOException {
		System.out.println("Indica cantidad a ingresar: ");
		float ingresar = Integer.parseInt(dato.readLine());
		try {
			System.out.println("Ingreso en cuenta");
			cuenta1.ingresar(ingresar);
		} catch (Exception e) {
			System.out.print("Fallo al ingresar");
		}
	}

	/**
	 * Metodo para recoger la opcion del menu y devolverla para su posterior
	 * uso.
	 * 
	 * @param dato
	 * @return Un entero, que sera la opcion que utilizaremos despues.
	 * @throws IOException
	 */
	private static int recogerOpcion(BufferedReader dato) throws IOException {
		int opcion;
		opcion = Integer.parseInt(dato.readLine());
		return opcion;
	}

	/**
	 * Metodo que muestra el menu
	 */
	private static void mostrarMenu() {
		System.out.println("MENU DE OPERACIONES");
		System.out.println("-------------------");
		System.out.println("1 - Ingresar");
		System.out.println("2 - Retirar");
		System.out.println("3 - Salir");
	}
}
