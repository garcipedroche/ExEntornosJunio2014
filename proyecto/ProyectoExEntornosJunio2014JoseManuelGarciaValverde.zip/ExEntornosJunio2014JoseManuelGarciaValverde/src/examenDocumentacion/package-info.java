/**
 * Paquete examenDocumentacion.
 * Almacena las clases CCuenta.java (funcionalidad) y TestCCuenta.java (pruebas de la clase CCuenta.java).
 *
 * @author Jose Manuel Garcia Valverde
 *
 */
package examenDocumentacion;